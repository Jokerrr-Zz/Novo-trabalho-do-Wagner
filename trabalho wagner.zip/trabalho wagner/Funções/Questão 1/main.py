def login():
    
    if email == 'admin' and senha == 'admin':
        return True
    else:
        return False



email = input("Digite o usuário: ")
senha = input("Digite a senha: ")

login(email, senha)

print(login(email, senha))