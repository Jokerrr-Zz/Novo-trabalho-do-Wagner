from funcoes_bolsa import *

acao = float(input("Digite o valor de sua ação: ")) 

checar(acao)