def imposto(valor):
    print(f"O valor final será {valor * 0.85}") 


valor = (float(input("Digite o seu valor:")))

imposto(valor)
